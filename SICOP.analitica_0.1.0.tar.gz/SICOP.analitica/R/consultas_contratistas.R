#' carga_datos
#'
#' @return carga_datos
#' @export
#'
pkg.globals <- new.env()

carga_datos <-function(){
  pkg.globals$datos_sicop <-na.omit(SICOP.datos::datos_sicop)
  pkg.globals$datos_sicop$ANO_ADJUDICADO <-as.numeric(pkg.globals$datos_sicop$ANO_ADJUDICADO)

  #if(pkg.globals$datos_sicop$MONEDA_ADJUDICADA!="CRC"){
    #format(pkg.globals$datos_sicop,decimal.mark=",")
    #columnas=c("PRECIO_UNITARIO", "TIPO_CAMBIO")
    #pkg.globals$datos_sicop[,columnas]=as.numeric(as.character(pkg.globals$datos_sicop[,columnas]))
    #pkg.globals$datos_sicop$PRECIO_UNITARIO <- as.numeric(apply(pkg.globals$datos_sicop[,columnas],1,sum))
    #columnas=c("MONTO_ADJUDICADO_LINEA", "TIPO_CAMBIO")
    #pkg.globals$datos_sicop[,columnas]=as.numeric(as.character(pkg.globals$datos_sicop[,columnas]))
    #pkg.globals$datos_sicop$MONTO_ADJUDICADO_LINEA <- as.numeric(apply(pkg.globals$datos_sicop[,columnas],1, sum))

  #}
  return()
}


#' consulta_contratistas__adjudicaciones_cantidad_anio
#'
#' @param cantidad cantidad de contratistas
#' @param anio  año de la adjudicacion
#'
#' @return consulta_contratistas__adjudicaciones_cantidad_anio
#' @importFrom sqldf sqldf
#' @export
#'

consulta_contratistas__adjudicaciones_cantidad_anio <-function(cantidad,anio){

  if(is.null(pkg.globals$datos_sicop)){carga_datos()}

  datos_sicop<-pkg.globals$datos_sicop
  consulta<-paste0("select * from datos_sicop where ANO_ADJUDICADO=",anio," order by MONTO_ADJUDICADO_LINEA desc limit ",cantidad)
  return(sqldf::sqldf(consulta))
}

