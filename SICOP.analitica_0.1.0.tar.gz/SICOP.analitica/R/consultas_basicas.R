
#' carga_datos
#'
#' @return carga_datos
#' @export
#'
pkg.globals <- new.env()

carga_datos <-function(){
  pkg.globals$datos_sicop <- SICOP.datos::datos_sicop
  pkg.globals$datos_sicop$ANO_ADJUDICADO <-as.numeric(pkg.globals$datos_sicop$ANO_ADJUDICADO)

  if(pkg.globals$datos_sicop$MONEDA_ADJUDICADA!="CRC"){

   columnas=c("PRECIO_UNITARIO", "TIPO_CAMBIO")
    pkg.globals$datos_sicop$MONTO_ADJUDICADO_LINEA <- as.numeric(apply(pkg.globals$datos_sicop[,columnas], 1, sum))

    }
  return()
  }

#' consulta_general
#'
#' @return consulta_general
#' @export


consulta_general <-function(){

  if(is.null(pkg.globals$datos_sicop)){carga_datos()}

  return(summary(pkg.globals$datos_sicop))
}


#' consulta_general_rango
#'
#' @return consulta_general
#' @export
consulta_general_rango <-function(inicio,final){

  if(is.null(inicio)){inicio<-2010}
  if(is.null(pkg.globals$datos_sicop)){carga_datos()}

  rango<-subset(pkg.globals$datos_sicop , ANO_ADJUDICADO >= inicio & ANO_ADJUDICADO <= final)
  return(summary(rango))
}


